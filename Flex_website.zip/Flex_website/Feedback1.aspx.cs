﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Feedback1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string teacher_ID = (TextBox1.Text);

        using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

        {
            connection.Open();

            SqlCommand cmd = new SqlCommand("SELECT Role FROM _User where User_ID = @TeacherID", connection);

            cmd.Parameters.AddWithValue("TeacherID", teacher_ID);

            string role = (string)cmd.ExecuteScalar();

            if (role == "Faculty")

                Response.Redirect("Feedback.aspx?&Teacher_ID=" + teacher_ID);


            else if (role == "Student" || role == "Academic Officer")


                Response.Write("<script>alert('The ID entered is not of a Faculty Member.')</script>");


        }


    }
}
