﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Specialized;
using System.Globalization;

public partial class _Default : System.Web.UI.Page

{
    protected void Page_Load(object sender, EventArgs e)

    {
        if (!IsPostBack)

        {
            string date = Request.QueryString["Date"];

            TextBox1.Text = date;
            string selectedValue = Request.QueryString["selectedValue"];
            DropDownList1.SelectedValue = selectedValue;
            DropDownList1.Enabled = false;

            string courseID = Request.QueryString["CourseID"];

            string sectionID = Request.QueryString["SectionID"];

            string semesterID = Request.QueryString["SemesterID"];

            // Console.WriteLine(semesterID);

            string query = "SELECT S_Details.Student_ID, _User.Name, S_Details.Roll_Number from S_Details " +
                 "inner join _User on _User.User_ID = S_Details.Student_ID " +
                 "INNER JOIN Student_Courses ON Student_Courses.Student_ID = S_Details.Student_ID " +
                 "inner join Section on Section.Section_ID = Student_Courses.Section_ID " +
                 "WHERE Student_Courses.Section_ID = @sectionID AND Student_Courses.Course_ID = @courseID AND Student_Courses.Semester_ID = @semesterID " +
                 "AND Section.Section_Name = @selectedValue " +
                 "ORDER BY S_Details.Roll_Number";

            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@sectionID", sectionID);
                command.Parameters.AddWithValue("@courseID", courseID);
                command.Parameters.AddWithValue("@semesterID", semesterID);
                command.Parameters.AddWithValue("@selectedValue", selectedValue);
                //   command.Parameters.AddWithValue("@sectionName", sectionname);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                GridView1.DataSource = dataTable;
                GridView1.DataBind();
            }

        }

    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)

    {

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)

    {
        string dateString = Request.QueryString["Date"]; 
     

        string courseID = Request.QueryString["CourseID"];

        string sectionID = Request.QueryString["SectionID"];

        string semesterID = Request.QueryString["SemesterID"];

        string duration = TextBox2.Text;

        if (duration == "")

        {

            Response.Write("<script>alert('Please Enter Duration.')</script>");
            return;
        }

        else

        {


            int teacherId = Convert.ToInt32(Session["teacher_id"]);


            int lectureNo = 1; // initialize lecture no to 1

            string checkAttendanceQuery = "SELECT COUNT(*) FROM Attendance WHERE Course_ID = @courseID";

            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                using (SqlCommand command = new SqlCommand(checkAttendanceQuery, connection))
                {
                    command.Parameters.AddWithValue("@courseID", courseID);
                    connection.Open();
                    int count = Convert.ToInt32(command.ExecuteScalar());
                    connection.Close();

                    if (count > 0) // if attendance has been taken before, get the latest lecture number
                    {
                        string getLectureNoQuery = "SELECT TOP 1 Lecture_No FROM Attendance WHERE Course_ID = @courseID ORDER BY Lecture_No DESC";
                        using (SqlCommand cmd = new SqlCommand(getLectureNoQuery, connection))
                        {
                            cmd.Parameters.AddWithValue("@courseID", courseID);
                            connection.Open();
                            int lastLectureNo = Convert.ToInt32(cmd.ExecuteScalar());
                            connection.Close();
                            lectureNo = lastLectureNo + 1; // increment lecture number from the last lecture number
                        }
                    }
                }
            }



            foreach (GridViewRow row in GridView1.Rows)

            {

                if (GridView1.DataKeys.Count > row.RowIndex)

                {

                    int studentID = Convert.ToInt32(GridView1.DataKeys[row.RowIndex].Value);

                    DropDownList ddlAttendance = (DropDownList)row.FindControl("ddlPresence");

                    string attendanceValue = ddlAttendance.SelectedValue;

                    string query = "INSERT INTO Attendance (Lecture_No,Date, Duration, Presence, Course_ID, Section_ID, Semester_ID, Teacher_ID, Student_ID) " +
                              "VALUES (@lectureNo,@date, @duration, @presence, @courseID, @sectionID, @semesterID, @teacherID, @studentID)";

                    using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

                    {
                        using (SqlCommand command = new SqlCommand(query, connection))

                        {
                            command.Parameters.AddWithValue("@lectureNo", lectureNo);
                            command.Parameters.AddWithValue("@date", dateString);
                            command.Parameters.AddWithValue("@duration", duration);
                            command.Parameters.AddWithValue("@presence", attendanceValue);
                            command.Parameters.AddWithValue("@courseID", courseID);
                            command.Parameters.AddWithValue("@sectionID", sectionID);
                            command.Parameters.AddWithValue("@semesterID", semesterID);
                            command.Parameters.AddWithValue("@teacherID", teacherId);
                            command.Parameters.AddWithValue("@studentID", studentID);

                            connection.Open();
                            command.ExecuteNonQuery();
                            connection.Close();
                        }
                    }


                    // Show a success message or redirect to another page
                    // Response.Write("<script>alert('Attendance has been saved successfully.')</script>");

                }


            }


        }


    }


}