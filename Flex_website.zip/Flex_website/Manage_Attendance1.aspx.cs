﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static System.Collections.Specialized.BitVector32;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {


        if (!IsPostBack)

        {
            int teacherId = Convert.ToInt32(Session["teacher_id"]);

            List<string> courses = new List<string>();

            courses.Insert(0, "-");

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT c.Course_Name FROM Teacher_Courses tc INNER JOIN Courses c ON tc.Course_ID = c.Course_ID WHERE tc.Teacher_ID = @TeacherID group by c.Course_Name", conn);
                cmd.Parameters.AddWithValue("@TeacherId", teacherId);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())

                {
                    courses.Add(reader.GetString(0));
                }
            }


            DropDownList1.DataSource = courses;
            DropDownList1.DataBind();

        }
    }

    protected void Button1_Click(object sender, EventArgs e)

    {

        int teacherId = Convert.ToInt32(Session["teacher_id"]);

        string Coursename = DropDownList1.SelectedValue;

        string sectionname = DropDownList2.SelectedValue;

        string date = TextBox1.Text;

        if(date == "")

        {
            Response.Write("<script>alert('Please Enter Date.')</script>");
            return;
        }


        using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

        {
            conn.Open();



            string query = "SELECT Courses.Course_Name,Teacher_Courses.Course_ID, Teacher_Courses.Section_ID,Teacher_Courses.Semester_ID from Teacher_Courses " +
                "Inner join Courses on Courses.Course_ID = Teacher_Courses.Course_ID " +
                "WHERE Teacher_ID = @teacherID AND Course_Name = @Coursename";


            SqlCommand cmd = new SqlCommand(query, conn);

            cmd.Parameters.AddWithValue("@teacherID", teacherId);


            cmd.Parameters.AddWithValue("@Coursename", Coursename);


            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())

            {

                string courseID = reader["Course_ID"].ToString();
                string sectionID = reader["Section_ID"].ToString();
                string semesterID = reader["Semester_ID"].ToString();


                Response.Redirect("Manage_Attendance2.aspx?Date=" + date + "&SelectedValue=" + sectionname + "&CourseID=" + courseID + "&SectionID=" + sectionID + "&SemesterID=" + semesterID);
            }

            reader.Close();
        }

    }


        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)


    {

        int teacherId = Convert.ToInt32(Session["teacher_id"]);

        string courseId = DropDownList1.SelectedValue;

   
        List<string> sections = new List<string>();

        using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT Section_Name from Teacher_Courses inner join Section on section.Section_ID = Teacher_Courses.Section_ID inner join Courses on Courses.Course_ID = Teacher_Courses.Course_ID where Teacher_ID = @TeacherId AND Courses.Course_Name = @CourseID", conn);

            cmd.Parameters.AddWithValue("@TeacherId", teacherId);

            cmd.Parameters.AddWithValue("@CourseID", courseId);

            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())

            {
                sections.Add(reader.GetString(0));

            }

            DropDownList2.DataSource = sections;
            DropDownList2.DataBind();
        }
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)

    {

    }
}