﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static System.Collections.Specialized.BitVector32;

public partial class AddMarks : System.Web.UI.Page

{


    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)

    {

        int teacherId = Convert.ToInt32(Session["teacher_id"]);
        string courseId = Request.QueryString["CourseID"];
        int sectionId = Convert.ToInt32(Request.QueryString["SectionID"]);
        int semesterId = Convert.ToInt32(Request.QueryString["SemesterID"]);
        int studentId = Convert.ToInt32(Request.QueryString["StudentID"]);

        int assignmentWeightage = Convert.ToInt32(Session["assignmentWeightage"]);

        int quizWeightage = Convert.ToInt32(Session["QuizWeightage"]);

        int mid1_Weightage = Convert.ToInt32(Session["Mid1Weightage"]);

        int mid2_Weightage = Convert.ToInt32(Session["Mid2Weightage"]);

        int project_Weightage = Convert.ToInt32(Session["ProjectWeightage"]);

        int final_weightage = Convert.ToInt32(Session["FinalWeightage"]);




        string evaluationName = DropDownList1.SelectedValue;

        int obtainedMarks = Convert.ToInt32(TextBox2.Text);

        int totalMarks = Convert.ToInt32(TextBox3.Text);

        int lastEvaluationNumber = 0;

        string connectionString = "Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True";

        using (SqlConnection connection = new SqlConnection(connectionString))

        {
            connection.Open();

            string query = "SELECT TOP 1 Evaluation_Number FROM Student_Marks WHERE Student_ID = @Student_ID AND Course_ID = @Course_ID AND Section_ID = @Section_ID AND Semester_ID = @Semester_ID AND Evaluation_Name = @Evaluation_Name ORDER BY Evaluation_Number DESC";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@Student_ID", studentId);

            command.Parameters.AddWithValue("@Course_ID", courseId);

            command.Parameters.AddWithValue("@Section_ID", sectionId);

            command.Parameters.AddWithValue("@Semester_ID", semesterId);

            command.Parameters.AddWithValue("@Evaluation_Name", evaluationName);

            SqlDataReader reader = command.ExecuteReader();

            if (reader.Read())

            {
                lastEvaluationNumber = Convert.ToInt32(reader["Evaluation_Number"]);
            }

            reader.Close();
        }

        // Calculate the evaluation number and grand total based on the last evaluation number and obtained marks

        int evaluationNumber = lastEvaluationNumber + 1;

        int assignment_grand_total = 0;

        int assignment_grand_total_marks = 0;

        float assignment_marks = 0;

        float quiz_marks = 0;


        float quiz_grand_total = 0;

        float quiz_grand_total_marks = 0;

        float mid1_marks = 0;

        float mid1_grand_total = 0;

        float mid1_grand_total_marks = 0;

        float mid2_marks = 0;

        float mid2_grand_total = 0;

        float mid2_grand_total_marks = 0;

        float project_marks = 0;

        float project_grand_total = 0;

        float project_grand_total_marks = 0;

        float final_marks = 0;

        float final_grand_total = 0;

        float final_grand_total_marks = 0;

        float total_marks = 0;
   


        connectionString = "Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True";

        using (SqlConnection connection = new SqlConnection(connectionString))

        {
            connection.Open();

            // Get the last grand total and grand total marks for the student

            string query = "SELECT TOP 1 assignment_grand_total, assignment_grand_total_marks, my_grand_total, assignment_marks, quiz_marks, quiz_grand_total, quiz_grand_total_marks, mid1_marks, mid1_grand_total, mid1_grand_total_marks, mid2_marks, mid2_grand_total, mid2_grand_total_marks, project_marks, project_grand_total, project_grand_total_marks, final_marks, final_grand_total, final_grand_total_marks FROM Student_Marks WHERE Student_ID = @Student_ID AND Course_ID = @Course_ID AND Section_ID = @Section_ID AND Semester_ID = @Semester_ID ORDER BY ID DESC";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@Student_ID", studentId);

            command.Parameters.AddWithValue("@Course_ID", courseId);

            command.Parameters.AddWithValue("@Section_ID", sectionId);

            command.Parameters.AddWithValue("@Semester_ID", semesterId);



            SqlDataReader reader = command.ExecuteReader();

            if (reader.Read())

            {
                assignment_marks = Convert.ToInt32(reader["assignment_marks"]);

                assignment_grand_total = Convert.ToInt32(reader["assignment_grand_total"]);

                assignment_grand_total_marks = Convert.ToInt32(reader["assignment_grand_total_marks"]);

               

                quiz_marks = Convert.ToInt32(reader["quiz_marks"]);

                quiz_grand_total = Convert.ToInt32(reader["quiz_grand_total"]);

                quiz_grand_total_marks = Convert.ToInt32(reader["quiz_grand_total_marks"]);

                mid1_marks = Convert.ToInt32(reader["mid1_marks"]);

                mid1_grand_total = Convert.ToInt32(reader["mid1_grand_total"]);

                mid1_grand_total_marks = Convert.ToInt32(reader["mid1_grand_total_marks"]);


                mid2_marks = Convert.ToInt32(reader["mid2_marks"]);

                mid2_grand_total = Convert.ToInt32(reader["mid2_grand_total"]);

                mid2_grand_total_marks = Convert.ToInt32(reader["mid2_grand_total_marks"]);


                project_marks = Convert.ToInt32(reader["project_marks"]);

                project_grand_total = Convert.ToInt32(reader["project_grand_total"]);

                project_grand_total_marks = Convert.ToInt32(reader["project_grand_total_marks"]);

                final_marks = Convert.ToInt32(reader["final_marks"]);

                final_grand_total = Convert.ToInt32(reader["final_grand_total"]);


                final_grand_total_marks = Convert.ToInt32(reader["final_grand_total_marks"]);


                total_marks = Convert.ToInt32(reader["my_grand_total"]);



            }

            reader.Close();

            // Calculate the new grand total and grand total marks

         //   float Percentage = ((float)grandTotal / grandTotalMarks) * 100;

            if(evaluationName == "Assignment")


            {

                assignment_grand_total += obtainedMarks;


                assignment_grand_total_marks += totalMarks;


                assignment_marks = ((float) assignment_grand_total / assignment_grand_total_marks) * assignmentWeightage;

               
            }

            else if(evaluationName == "Quiz")

            {


                quiz_grand_total += obtainedMarks;

                quiz_grand_total_marks += totalMarks;


              quiz_marks = ((float) quiz_grand_total / quiz_grand_total_marks) * quizWeightage;

            }


            else if(evaluationName == "Mid 1")

            {

                mid1_grand_total += obtainedMarks;

                mid1_grand_total_marks += totalMarks;

                mid1_marks = ((float)mid1_grand_total / mid1_grand_total_marks) * mid1_Weightage;

            }

            else if (evaluationName == "Mid 2")

            {

                mid2_grand_total += obtainedMarks;

                mid2_grand_total_marks += totalMarks;

                mid2_marks = ((float)mid2_grand_total / mid2_grand_total_marks) * mid2_Weightage;

            }

            else if (evaluationName == "Project")

            {

                project_grand_total += obtainedMarks;

                project_grand_total_marks += totalMarks;

                project_marks = ((float) project_grand_total / project_grand_total_marks) * project_Weightage;

            }

            else if (evaluationName == "Final")

            {

                final_grand_total += obtainedMarks;

                final_grand_total_marks += totalMarks;

                final_marks = ((float)final_grand_total / final_grand_total_marks) * final_weightage;

            }


            if((evaluationNumber == 2 && evaluationName == "Mid 1") || (evaluationNumber == 2 && evaluationName == "Mid 2") || (evaluationNumber == 2 && evaluationName == "Project") || (evaluationNumber == 2 && evaluationName == "Final" ))

            {

                Response.Write("<script>alert('Marks for this evaluation have already been added.')</script>");

                return;
            }

            total_marks = assignment_marks + quiz_marks + mid1_marks + mid2_marks + project_marks + final_marks;


            query = "INSERT INTO Student_Marks (Student_ID, Teacher_ID, Course_ID, Section_ID, Semester_ID, Evaluation_Name, Evaluation_Number, Obtained_Marks, Total_Marks , assignment_marks, assignment_grand_total , assignment_grand_total_marks, quiz_marks, quiz_grand_total, quiz_grand_total_marks, mid1_marks, mid1_grand_total, mid1_grand_total_marks, mid2_marks, mid2_grand_total, mid2_grand_total_marks, project_marks, project_grand_total, project_grand_total_marks, final_marks, final_grand_total, final_grand_total_marks, my_grand_total) VALUES (@Student_ID, @Teacher_ID, @Course_ID, @Section_ID, @Semester_ID, @Evaluation_Name, @Evaluation_Number, @Obtained_Marks, @Total_Marks, @assignmentmarks, @assignment_grand_total, @assignment_grand_total_marks, @quizmarks, @quiz_grand_total ,@quiz_grand_total_marks , @mid1_marks, @mid1_grand_total,@mid1_grand_total_marks, @mid2_marks, @mid2_grand_total, @mid2_grand_total_marks, @project_marks, @project_grand_total, @project_grand_total_marks, @final_marks, @final_grand_total, @final_grand_total_marks ,@my_grand_total)";

            command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@Student_ID", studentId);
            command.Parameters.AddWithValue("@Teacher_ID", teacherId);
            command.Parameters.AddWithValue("@Course_ID", courseId);
            command.Parameters.AddWithValue("@Section_ID", sectionId);
            command.Parameters.AddWithValue("@Semester_ID", semesterId);
            command.Parameters.AddWithValue("@Evaluation_Name", evaluationName);
            command.Parameters.AddWithValue("@Evaluation_Number", evaluationNumber);
            command.Parameters.AddWithValue("@Obtained_Marks", obtainedMarks);
            command.Parameters.AddWithValue("@Total_Marks", totalMarks);
           

            command.Parameters.AddWithValue("@assignmentmarks", assignment_marks);

            command.Parameters.AddWithValue("@assignment_grand_total", assignment_grand_total);

            command.Parameters.AddWithValue("@assignment_grand_total_marks", assignment_grand_total_marks);

            command.Parameters.AddWithValue("@quizmarks", quiz_marks);


            command.Parameters.AddWithValue("@quiz_grand_total", quiz_grand_total);


            command.Parameters.AddWithValue("@quiz_grand_total_marks", quiz_grand_total_marks);

            command.Parameters.AddWithValue("@mid1_marks", mid1_marks);


            command.Parameters.AddWithValue("@mid1_grand_total", mid1_grand_total);

            command.Parameters.AddWithValue("@mid1_grand_total_marks", mid1_grand_total_marks);

            command.Parameters.AddWithValue("@mid2_marks", mid2_marks);


            command.Parameters.AddWithValue("@mid2_grand_total", mid2_grand_total);

            command.Parameters.AddWithValue("@mid2_grand_total_marks", mid2_grand_total_marks);

            command.Parameters.AddWithValue("@project_marks", project_marks);

            command.Parameters.AddWithValue("@project_grand_total", project_grand_total);

            command.Parameters.AddWithValue("@project_grand_total_marks", project_grand_total_marks);

            command.Parameters.AddWithValue("@final_marks", final_marks);

            command.Parameters.AddWithValue("@final_grand_total", final_grand_total);

            command.Parameters.AddWithValue("@final_grand_total_marks", final_grand_total_marks);




            command.Parameters.AddWithValue("@my_grand_total", total_marks);
        

         
            command.ExecuteNonQuery();

            Response.Write("<script>alert('Marks have been added successfully for the current student.')</script>");

            if(evaluationName == "Final")

            {

                string grade_type = "";

              

               if(total_marks >= 90)

                {

                   grade_type = "A+";
               }

               else if (total_marks >= 86 && total_marks <= 89)

                {
                    grade_type = "A";
                }

                else if (total_marks >= 82 && total_marks <= 85)

                {
                    grade_type = "A-";
                }

                else if (total_marks >= 78 && total_marks <= 81)

               {
                   grade_type = "B+";
               }

                else if (total_marks >= 74 && total_marks <= 77)

               {
                    grade_type = "B";
               }

               else if (total_marks >= 70 && total_marks <= 73)

               {
                    grade_type = "B-";
               }

                else if (total_marks >= 66 && total_marks <= 69)

                {
                    grade_type = "C+";
                }

               else if (total_marks >= 62 && total_marks <= 65)

                {
                    grade_type = "C";
                }

                else if (total_marks >= 58 && total_marks <= 61)

                {
                    grade_type = "C-";
                }

                else if (total_marks >= 54 && total_marks <= 57)

                {
                    grade_type = "D+";
                }

               else if (total_marks >= 50 && total_marks <= 53)

                {
                    grade_type = "D";
                }

                else if (total_marks <= 49)

                {
                    grade_type = "F";
                }


               query = "Insert into Grades (Course_ID,Student_ID,Teacher_ID,Section_ID,Semester_ID,Grade_Type) Values (@Course_ID,@Student_ID,@Teacher_ID,@Section_ID,@Semester_ID,@GradeType)";

                command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@GradeType", grade_type);
                command.Parameters.AddWithValue("@Student_ID", studentId);
                command.Parameters.AddWithValue("@Teacher_ID", teacherId);
                command.Parameters.AddWithValue("@Course_ID", courseId);
                command.Parameters.AddWithValue("@Section_ID", sectionId);
                command.Parameters.AddWithValue("@Semester_ID", semesterId);
                command.ExecuteNonQuery();

            }

        }
    }
}


