﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class StudentSections : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {

        if (!IsPostBack)

        {

            List<int> sections = new List<int>();


            sections.Insert(0, 0);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                conn.Open();

                SqlCommand cmd = new SqlCommand("SELECT Section_ID from Section", conn);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())

                {
                    sections.Add(reader.GetInt32(0));
                }
            }

            DropDownList1.DataSource = sections;
            DropDownList1.DataBind();


        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)

    {
        int section_ID = Convert.ToInt32(DropDownList1.SelectedValue);

        Session["sectionID"] = section_ID;

    }

    protected void Button1_Click(object sender, EventArgs e)

    {
        int section_ID = Convert.ToInt32(Session["sectionID"]);

        if(section_ID == 0) 
        
        {
            Response.Write("<script>alert('Please select valid section.')</script>");
        }

        else

        Response.Redirect("StudentSections1.aspx?Section_ID=" + section_ID);
    }
}