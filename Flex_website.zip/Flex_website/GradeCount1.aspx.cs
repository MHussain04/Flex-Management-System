﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GradeCount1 : System.Web.UI.Page

{
    protected void Page_Load(object sender, EventArgs e)

    {
        if (!IsPostBack)

        {

            int teacherId = Convert.ToInt32(Session["teacher_id"]);
            string courseId = Request.QueryString["CourseID"];
            int sectionId = Convert.ToInt32(Request.QueryString["SectionID"]);
            int semesterId = Convert.ToInt32(Request.QueryString["SemesterID"]);


            string connectionString = "Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True";
            string query = "SELECT " +
                "  COUNT(CASE WHEN Grade_Type = 'A+' THEN 1 END) AS 'A+', " +
                "  COUNT(CASE WHEN Grade_Type = 'A-' THEN 1 END) AS 'A-', " +
                "  COUNT(CASE WHEN Grade_Type = 'A' THEN 1 END) AS 'A', " +
                "  COUNT(CASE WHEN Grade_Type = 'B+' THEN 1 END) AS 'B+', " +
                "  COUNT(CASE WHEN Grade_Type = 'B-' THEN 1 END) AS 'B-', " +
                "  COUNT(CASE WHEN Grade_Type = 'B' THEN 1 END) AS 'B', " +
                "  COUNT(CASE WHEN Grade_Type = 'C+' THEN 1 END) AS 'C+', " +
                "  COUNT(CASE WHEN Grade_Type = 'C' THEN 1 END) AS 'C', " +
                "  COUNT(CASE WHEN Grade_Type = 'C-' THEN 1 END) AS 'C-', " +
                "  COUNT(CASE WHEN Grade_Type = 'D+' THEN 1 END) AS 'D+', " +
                "  COUNT(CASE WHEN Grade_Type = 'D' THEN 1 END) AS 'D', " +
                "  COUNT(CASE WHEN Grade_Type = 'F' THEN 1 END) AS 'F' " +
                "FROM Grades " +

                "WHERE Course_ID = @CourseId AND Section_ID = @SectionId AND Semester_ID = @SemesterId AND Teacher_ID = @TeacherId ";


            using (SqlConnection connection = new SqlConnection(connectionString))

            {
                SqlCommand cmd = new SqlCommand(query, connection);


                cmd.Parameters.AddWithValue("@TeacherId", teacherId);
                cmd.Parameters.AddWithValue("@CourseId", courseId);
                cmd.Parameters.AddWithValue("@SectionId", sectionId);
                cmd.Parameters.AddWithValue("@SemesterId", semesterId);


                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                gradesGridView.DataSource = dataTable;
                gradesGridView.DataBind();
            }
        }
    }
}