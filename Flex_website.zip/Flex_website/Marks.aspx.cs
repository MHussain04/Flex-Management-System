﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Marks : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {

        if (!IsPostBack)

        {
            int studentId = Convert.ToInt32(Session["student_id"]);

            List<string> courses = new List<string>();

            courses.Insert(0, "-");

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                conn.Open();

                SqlCommand cmd = new SqlCommand("SELECT c.Course_Name FROM Student_Courses sc INNER JOIN Courses c ON sc.Course_ID = c.Course_ID WHERE sc.Student_ID = @StudentID group by c.Course_Name", conn);

                cmd.Parameters.AddWithValue("@StudentID", studentId);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())

                {
                    courses.Add(reader.GetString(0));
                }
            }


            DropDownList1.DataSource = courses;
            DropDownList1.DataBind();

        }

    }

    protected void Button1_Click(object sender, EventArgs e)

    {
        string coursename = DropDownList1.SelectedValue;

        int StudentID = Convert.ToInt32(Session["student_id"]);

        using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

        {
            conn.Open();



            string query = "SELECT Course_Name,Student_Courses.Course_ID, Student_Courses.Section_ID,Student_Courses.Semester_ID FROM Student_Courses " +
                "Inner join Courses on Courses.Course_ID = Student_Courses.Course_ID" +
                " WHERE Student_ID = @StudentID AND Courses.Course_Name = @CourseName";


            SqlCommand cmd = new SqlCommand(query, conn);

            cmd.Parameters.AddWithValue("@StudentID", StudentID);

            cmd.Parameters.AddWithValue("@CourseName", coursename);


            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())

            {

                string courseID = reader["Course_ID"].ToString();
                string sectionID = reader["Section_ID"].ToString();
                string semesterID = reader["Semester_ID"].ToString();


                Response.Redirect("Marks1.aspx?CourseName=" + coursename + "&CourseID=" + courseID + "&SectionID=" + sectionID + "&SemesterID=" + semesterID);
            }

            reader.Close();
        }


    }


protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)

    {

    }
}