﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

public partial class StudentRegistration : System.Web.UI.Page

{
    protected void Page_Load(object sender, EventArgs e)

    {

    }

    protected void Button1_Click(object sender, EventArgs e)

    {

        string name = TextBox1.Text;

        string rollNumber = TextBox2.Text;

        string pattern = @"^[a-zA-Z]{3}-[0-9]{4}$"; // Regular Expression pattern for XXX-XXXX format

        Regex regex = new Regex(@"^\d{2}[A-Z]-\d{4}$");

        if (!regex.IsMatch(rollNumber))
        {

            Response.Write("<script>alert('Roll number format should be like 21I-0501')</script>");
            return;
        }

        string batch = TextBox3.Text;

        int sectionId = int.Parse(TextBox4.Text);


        string email = TextBox5.Text;

        string campus = TextBox6.Text;

        string degree = TextBox7.Text;

        string mobile = TextBox8.Text;

        string cnic = TextBox9.Text;

        string address = TextBox10.Text;


        DateTime dob = DateTime.Parse(TextBox11.Text).Date;

        string bloodGroup = TextBox12.Text;

        string gender = DropDownList1.SelectedValue;

        string username = TextBox13.Text;

        string password = TextBox14.Text;

        string role = "Student"; // Assuming this is a student registration form


        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True");

        conn.Open();

        SqlCommand cmdCheck = new SqlCommand("SELECT COUNT(*) FROM S_Details WHERE Roll_Number = @RollNumber", conn);

        cmdCheck.Parameters.AddWithValue("@RollNumber", rollNumber);

        int count = Convert.ToInt32(cmdCheck.ExecuteScalar());

        if (count > 0)
        {
            Response.Write("<script>alert('A student with the same roll number already exists.')</script>");
            return;
        }



        SqlCommand cmdCount = new SqlCommand("SELECT COUNT(*) FROM S_Details WHERE Section_ID = @SectionID", conn);

        cmdCount.Parameters.AddWithValue("@SectionID", sectionId);

        int studentCount = Convert.ToInt32(cmdCount.ExecuteScalar());

        if (studentCount >= 50)

        {
            Response.Write("<script>alert('This section already has 50 students. Please choose a different section.')</script>");
            return;
        }


        if (!regex.IsMatch(rollNumber))

        {

            Response.Write("<script>alert('Roll number format should be like 21I-0501')</script>");
            return;
        }


        else

        {

            SqlCommand cmdUser = new SqlCommand("INSERT INTO _User (Name, Email, Mobile_No, CNIC, Address, DOB, Blood_Group, Gender, Username, Password, Role) VALUES (@Name, @Email, @Mobile, @CNIC, @Address, @DOB, @BloodGroup, @Gender, @Username, @Password, @Role); SELECT SCOPE_IDENTITY();", conn);
            cmdUser.Parameters.AddWithValue("@Name", name);
            cmdUser.Parameters.AddWithValue("@Email", email);
            cmdUser.Parameters.AddWithValue("@Mobile", mobile);
            cmdUser.Parameters.AddWithValue("@CNIC", cnic);
            cmdUser.Parameters.AddWithValue("@Address", address);
            cmdUser.Parameters.AddWithValue("@DOB", dob);
            cmdUser.Parameters.AddWithValue("@BloodGroup", bloodGroup);
            cmdUser.Parameters.AddWithValue("@Gender", gender);
            cmdUser.Parameters.AddWithValue("@Username", username);
            cmdUser.Parameters.AddWithValue("@Password", password);
            cmdUser.Parameters.AddWithValue("@Role", role);

            int userId = Convert.ToInt32(cmdUser.ExecuteScalar());


            SqlCommand cmdStudent = new SqlCommand("INSERT INTO S_Details (Student_ID, Roll_Number, Batch, Campus, Degree, Section_ID) VALUES (@StudentID, @RollNumber, @Batch, @Campus, @Degree, @SectionID);", conn);
            cmdStudent.Parameters.AddWithValue("@StudentID", userId);
            cmdStudent.Parameters.AddWithValue("@RollNumber", rollNumber);
            cmdStudent.Parameters.AddWithValue("@Batch", batch);
            cmdStudent.Parameters.AddWithValue("@Campus", campus);
            cmdStudent.Parameters.AddWithValue("@Degree", degree);
            cmdStudent.Parameters.AddWithValue("@SectionID", sectionId);



            Response.Write("<script>alert('Student has been registered successfully.')</script>");


            cmdStudent.ExecuteNonQuery();


        }

    }



}

      
       
   