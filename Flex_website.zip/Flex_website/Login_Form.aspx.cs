﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login_Form : System.Web.UI.Page

{
    protected void Page_Load(object sender, EventArgs e)

    {

    }




    protected void Button1_Click(object sender, EventArgs e)

    {
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True");
        conn.Open();
        SqlCommand cm;
        string un = TextBox8.Text;
        string pass = TextBox9.Text;
        string query = "SELECT * FROM _User WHERE Username = '" + un + "' AND Password = '" + pass + "'";
        cm = new SqlCommand(query, conn);
        SqlDataReader res = cm.ExecuteReader();

        if (!res.HasRows)


        {

            Response.Write("<script>alert('No such username found.')</script>");

        }


        else

        {
            res.Read();
            Session["Name"] = res["Name"];
            Session["Email"] = res["Email"];
            Session["Mobile_No"] = res["Mobile_No"];
            Session["CNIC"] = res["CNIC"];
            Session["Address"] = res["Address"];
            Session["DOB"] = res["DOB"];
            Session["Blood_Group"] = res["Blood_Group"];
            Session["Gender"] = res["Gender"];
            Session["Campus"] = res["Campus"];

            string role = res["Role"].ToString();

            if (role == "Student")
            {

                res.Close(); // close the SqlDataReader before running the second query

                query = "SELECT * FROM _User, S_Details WHERE _User.Username = '" + un + "' AND _User.Password = '" + pass + "'";

                cm = new SqlCommand(query, conn);

                SqlDataReader studentRes = cm.ExecuteReader();

                if (!studentRes.HasRows)

                {
                    Response.Write("<script>alert('No such username found.')</script>");

                }

                else

                {
                    studentRes.Read();

                    Session["student_id"] = studentRes["User_ID"];
                    Session["Section_ID"] = studentRes["Section_ID"];
                    //   string studentID = Request.QueryString["student_id"];
                    Session["Roll_Number"] = studentRes["Roll_Number"];
                    Session["Batch"] = studentRes["Batch"];
                    Session["Degree"] = studentRes["Degree"];
                   // Session["CGPA"] = studentRes["CGPA"];
                    Response.Redirect("HomePage.aspx");
                }

                studentRes.Close(); // close the SqlDataReader
            }

            else if (role == "Faculty")

            {
                Session["teacher_id"] = res["User_ID"];
             
                Response.Redirect("TeacherHomePage.aspx");
            }

            else if(role == "Academic Officer")

            {
                Session["admin_id"] = res["User_ID"];
                Response.Redirect("AdminHomePage.aspx");
            }

       
        }

        cm.Dispose();
        conn.Close();

    }

}