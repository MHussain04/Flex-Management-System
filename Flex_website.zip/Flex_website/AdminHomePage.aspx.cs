﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminHomePage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {
        string name = (string)Session["Name"];
        string email = (string)Session["Email"];
        string mobileNo = (string)Session["Mobile_No"];
        string cnic = (string)Session["CNIC"];
        string address = (string)Session["Address"];
        DateTime dob = (DateTime)Session["DOB"];
        string dateOnly = dob.ToString("dd/MM/yyyy");
        string bloodGroup = (string)Session["Blood_Group"];
        string gender = (string)Session["Gender"];
        string campus = (string)Session["Campus"];


        Label3.Text = "Name: " + name;
        Label4.Text = "DOB: " + dateOnly;
        Label5.Text = "Blood Group: " + bloodGroup;
        Label6.Text = "Gender: " + gender;
        Label7.Text = "CNIC: " + cnic;
        Label8.Text = "Email: " + email;
        Label9.Text = "Mobile Number: " + mobileNo;
        Label10.Text = "Address: " + address;
        Label12.Text = "Campus: " + campus; 
    }

    protected void LinkButton1_Click(object sender, EventArgs e)

    {
        Response.Redirect("UserRegistration.aspx");
    }

    protected void LinkButton3_Click(object sender, EventArgs e)

    {
        Response.Redirect("CourseAllocation.aspx");
    }

    protected void LinkButton8_Click(object sender, EventArgs e)
    {
        Response.Redirect("AdminCourseRegistration.aspx");
    }

    protected void LinkButton9_Click(object sender, EventArgs e)
    {
        Response.Redirect("OfferedCourses.aspx");
    }

    protected void LinkButton10_Click(object sender, EventArgs e)
    {
        Response.Redirect("StudentSections.aspx");
    }
}