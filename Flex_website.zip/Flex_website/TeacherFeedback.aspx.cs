﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static System.Collections.Specialized.BitVector32;

public partial class TeacherFeedback : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {
        int teacherId = Convert.ToInt32(Session["teacher_id"]);

        using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

        {
            conn.Open();

            string query = "Select comments from Feedback where Feedback.Teacher_ID = @Teacher_Id ";

            SqlCommand cmd = new SqlCommand(query, conn);

            //   cmd.Parameters.AddWithValue("@TeacherId", teacherId);
            cmd.Parameters.AddWithValue("@Teacher_Id", teacherId);
          


            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)

            {
                MarksGridView.DataSource = reader;
                MarksGridView.DataBind();
            }

            else

            {
                // If no marks are found, display a message to the teacher
                MarksGridView.Visible = false;

                Response.Write("<script>alert('No Feedback has been generated yet.')</script>");

            }

            reader.Close();
        }
    }


    protected void MarksGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}