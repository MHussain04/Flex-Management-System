﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AllocatedCourses : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {
        if (!IsPostBack)

        {
            int teacherId = Convert.ToInt32(Session["teacher_id"]);

            string connectionString = "Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True";

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                conn.Open();

                string query = "select Teacher_Courses.Course_ID, Courses.Course_Name,Courses.Course_Type,Section.Section_Name,Semester.Semester_Name from Teacher_Courses " +

                   "inner join Courses on Courses.Course_ID = Teacher_Courses.Course_ID " +

                   "inner join Section on Section.Section_ID = Teacher_Courses.Section_ID " +

                   "inner join Semester on Semester.Semester_ID = Teacher_Courses.Semester_ID " +

                   "where Teacher_Courses.Teacher_ID = @TeacherId order by Teacher_Courses.Course_ID";


                SqlCommand cmd = new SqlCommand(query, conn);


                cmd.Parameters.AddWithValue("@TeacherId", teacherId);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)

                {
                    GridView1.DataSource = reader;
                    GridView1.DataBind();
                }

                else

                {
                    
                    GridView1.Visible = false;

                    Response.Write("<script>alert('You have not been allocated any courses yet.')</script>");

                }

                reader.Close();
            }
        }


    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)

    {

    }
}