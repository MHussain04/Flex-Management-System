﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HomePage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
      
        string name = (string)Session["Name"];
        string email = (string)Session["Email"];
        string mobileNo = (string)Session["Mobile_No"];
        string cnic = (string)Session["CNIC"];
        string address = (string)Session["Address"];
        DateTime dob = (DateTime)Session["DOB"];
        string dateOnly = dob.ToString("dd/MM/yyyy");
        string bloodGroup = (string)Session["Blood_Group"];
        string Roll_Number = (string)Session["Roll_Number"];
        string gender = (string)Session["Gender"];
        string degree = (string)Session["Degree"];
        string batch = (string)Session["Batch"];
        string campus = (string)Session["Campus"];

        int sectionId = Convert.ToInt32(Session["Section_ID"]);

        string connectionString = "Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            string query = "SELECT Section_Name FROM Section WHERE Section_ID = @SectionId";
            SqlCommand command = new SqlCommand(query, connection);
            command.Parameters.AddWithValue("@SectionId", sectionId);

            SqlDataReader reader = command.ExecuteReader();

            if (reader.Read())

            {
                string sectionName = reader.GetString(reader.GetOrdinal("Section_Name"));


                Label3.Text = "Roll Number: " + Roll_Number;
                Label4.Text = "Degree: " + degree;
                Label5.Text = "Batch: " + batch;
                Label6.Text = "Section:" + sectionName;
                Label7.Text = "Campus: " + campus;

                Label10.Text = "Name: " + name;
                Label11.Text = "DOB: " + dateOnly;
                Label12.Text = "Blood Group: " + bloodGroup;
                Label13.Text = "Gender: " + gender;
                Label14.Text = "CNIC: " + cnic;
                Label15.Text = "Email: " + email;
                Label16.Text = "Mobile Number: " + mobileNo;
                Label18.Text = "Address: " + address;

            }


        }
    }

    protected void LinkButton4_Click(object sender, EventArgs e)

    {
        Response.Redirect("Transcript.aspx");
    }

    protected void LinkButton6_Click(object sender, EventArgs e)
    {
        Response.Redirect("HomePage.aspx");
    }

    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Attendance.aspx");
    }

    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        Response.Redirect("Marks.aspx");
    }

    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Response.Redirect("ShowRegistration.aspx");
    }

    protected void LinkButton7_Click(object sender, EventArgs e)
    {
        Response.Redirect("Feedback1.aspx");
    }
}