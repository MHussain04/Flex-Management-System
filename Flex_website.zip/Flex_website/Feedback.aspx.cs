﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Feedback : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        string feedback = TextBox8.Text;
        string teacherID = Request.QueryString["Teacher_ID"];

        string connectionString = "Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"; // replace with your actual connection string
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            string query = "INSERT INTO Feedback (comments, Teacher_ID) VALUES (@comments, @teacherID)";

            using (SqlCommand command = new SqlCommand(query, connection))

            {
                command.Parameters.AddWithValue("@comments", feedback);
                command.Parameters.AddWithValue("@teacherID", teacherID);
                int rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    Response.Write("<script>alert('Feedback was inserted successfully.')</script>");
                }
             
            }
        }
    }

}