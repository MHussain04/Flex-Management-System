﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Transcript : System.Web.UI.Page

{
    protected void Page_Load(object sender, EventArgs e)

    {

        int StudentID = Convert.ToInt32(Session["student_id"]);

        using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

        {
            conn.Open();

            string query = "Select Grades.Course_ID, Courses.Course_Name,Section.Section_Name,Courses.Credits, Grades.Grade_Type from Grades " +

                "inner join Courses on courses.Course_ID = Grades.Course_ID " +

                "inner join Section on Section.Section_ID = Grades.Section_ID " +

                "where Grades.Student_ID = @studentID order by Courses.Course_ID ";

            SqlCommand cmd = new SqlCommand(query, conn);

            cmd.Parameters.AddWithValue("@studentID", StudentID);


            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)

            {
                GridView1.DataSource = reader;

                GridView1.DataBind();
            }

            else

            {
                // If no marks are found, display a message to the teacher
                GridView1.Visible = false;

                Response.Write("<script>alert('No Grades have been generated yet.')</script>");

            }

            reader.Close();

        }

    }

        protected void MarksGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}