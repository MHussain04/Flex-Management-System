﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GradeReport1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {
        if (!IsPostBack)

        {
            int teacherId = Convert.ToInt32(Session["teacher_id"]);
            string courseId = Request.QueryString["CourseID"];
            int sectionId = Convert.ToInt32(Request.QueryString["SectionID"]);
            int semesterId = Convert.ToInt32(Request.QueryString["SemesterID"]);


            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                conn.Open();

                string query = "SELECT S_Details.Roll_Number, _User.Name, Section.Section_Name, Student_Marks.my_grand_total, Grades.Grade_Type FROM Grades " +

                               "INNER JOIN S_Details ON S_Details.Student_ID = Grades.Student_ID " +

                               "INNER JOIN _User ON _User.User_ID = Grades.Student_ID " +

                               "INNER JOIN Section ON Section.Section_ID = Grades.Section_ID " +

                               "INNER JOIN Student_Marks ON Student_Marks.Student_ID = Grades.Student_ID " +

                               "INNER JOIN (SELECT Student_ID, MAX(ID) AS Latest_ID FROM Student_Marks GROUP BY Student_ID) " +

                               "Latest_Marks ON Latest_Marks.Student_ID = Student_Marks.Student_ID AND Latest_Marks.Latest_ID = Student_Marks.ID " +

                               "WHERE Grades.Course_ID IN (SELECT Course_ID FROM Courses WHERE Courses.Course_ID = @CourseId) " +

                               "AND Grades.Semester_ID IN (SELECT Semester_ID FROM Semester WHERE Semester.Semester_ID = @SemesterId) " +

                               "AND Grades.Section_ID IN (SELECT Section_ID FROM Section WHERE Section.Section_ID = @SectionId)";


                SqlCommand cmd = new SqlCommand(query, conn);

             //   cmd.Parameters.AddWithValue("@TeacherId", teacherId);
                cmd.Parameters.AddWithValue("@CourseId", courseId);
                cmd.Parameters.AddWithValue("@SectionId", sectionId);
                cmd.Parameters.AddWithValue("@SemesterId", semesterId);
                

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)

                {
                    MarksGridView.DataSource = reader;
                    MarksGridView.DataBind();
                }

                else

                {
                    // If no marks are found, display a message to the teacher
                    MarksGridView.Visible = false;

                    Response.Write("<script>alert('No Grades have been generated yet for this course.')</script>");

                }

                reader.Close();
            }
        }

    }
            protected void MarksGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}