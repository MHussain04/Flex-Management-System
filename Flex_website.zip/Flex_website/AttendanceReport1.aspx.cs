﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AttendanceReport1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {
        if (!IsPostBack)

        {
            int teacherId = Convert.ToInt32(Session["teacher_id"]);
            string courseId = Request.QueryString["CourseID"];
            int sectionId = Convert.ToInt32(Request.QueryString["SectionID"]);
            int semesterId = Convert.ToInt32(Request.QueryString["SemesterID"]);


            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                conn.Open();

                string query = "Select Date, Lecture_No, Duration, S_details.Roll_Number, _User.Name, Presence from Attendance " +

                               "inner join S_Details on S_Details.Student_ID = Attendance.Student_ID " +

                               "inner join _User on _User.User_ID = S_Details.Student_ID " +

                               "where Course_ID = @CourseId AND Attendance.Section_ID = @SectionId AND Attendance.Semester_ID = @SemesterId ";



                SqlCommand cmd = new SqlCommand(query, conn);

                //   cmd.Parameters.AddWithValue("@TeacherId", teacherId);
                cmd.Parameters.AddWithValue("@CourseId", courseId);
                cmd.Parameters.AddWithValue("@SectionId", sectionId);
                cmd.Parameters.AddWithValue("@SemesterId", semesterId);


                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)

                {
                    MarksGridView.DataSource = reader;
                    MarksGridView.DataBind();
                }

                else

                {
                    // If no marks are found, display a message to the teacher
                    MarksGridView.Visible = false;

                    Response.Write("<script>alert('No Attendance has been generated yet for this course.')</script>");

                }

                reader.Close();
            }
        }

    }

    protected void MarksGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}