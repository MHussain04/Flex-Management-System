﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CourseRegistration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {

        int studentId = Convert.ToInt32(Session["student_id"]);

        string connectionString = "Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True";


        string query = "SELECT Course_ID, Course_Name, Credits, Course_Type, Semester_Name " +
               "FROM Courses " +
               "INNER JOIN Semester ON Courses.Semester_ID = Semester.Semester_ID " +
               //  "INNER JOIN Section ON Courses.Semester_ID = Section.Semester_ID " +
               "GROUP BY Courses.Course_ID, Courses.Course_Name, Courses.Credits, Courses.Course_Type, Semester.Semester_Name " +
               "ORDER BY Courses.Course_ID";

        using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

        {
            SqlCommand command = new SqlCommand(query, connection);
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();

            // Bind the data to the GridView control
            GridView1.DataSource = reader;
            GridView1.DataBind();

            reader.Close();
        }


    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)

    {
        if (e.CommandName == "Register")
        {
            int rowIndex = Convert.ToInt32(e.CommandArgument);

            GridViewRow row = GridView1.Rows[rowIndex];
            string courseID = row.Cells[0].Text;
            string semesterName = row.Cells[4].Text;

            int studentID = Convert.ToInt32(Session["student_id"]);

            string connectionString = "Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))

            {

                string query = "SELECT Section_ID FROM S_Details WHERE Student_ID = @studentID";

                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@studentID", studentID);

                connection.Open();

                int sectionID = Convert.ToInt32(command.ExecuteScalar());

                connection.Close();


                query = "SELECT Semester_ID FROM Semester WHERE Semester_Name = @semesterName";

                command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@semesterName", semesterName);

                connection.Open();

                int semesterID = Convert.ToInt32(command.ExecuteScalar());

                connection.Close();


                query = "SELECT COUNT(*) FROM Student_Courses WHERE Student_ID = @studentID AND Course_ID = @courseID";

                command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@studentID", studentID);

                command.Parameters.AddWithValue("@courseID", courseID);


                connection.Open();

                int count = Convert.ToInt32(command.ExecuteScalar());

                connection.Close();

                if (count > 0)

                {
                    
                    Response.Write("<script>alert('You have already registered for this course.')</script>");
                }


                else

                {
                   
                    query = "SELECT COUNT(*) FROM Student_Courses " +
                            "inner join Semester on Semester.Semester_ID = Student_Courses.Semester_ID " +
                           "WHERE Student_ID = @studentID AND Semester.Semester_Name = @semesterName";

                    command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@studentID", studentID);
                    command.Parameters.AddWithValue("@semesterName", semesterName);

                    connection.Open();

                    count = Convert.ToInt32(command.ExecuteScalar());

                    connection.Close();

                    if (count >= 6)
                    {
                        // The student has reached the maximum number of registrations
                        Response.Write("<script>alert('You have already registered for 6 courses.')</script>");

                    }

                    else

                    {
                        query = "INSERT INTO Student_Courses (Student_ID, Course_ID, Section_ID, Semester_ID) " +
                        "VALUES (@studentID, @courseID, @sectionID, @semesterID)";
                        command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@studentID", studentID);
                        command.Parameters.AddWithValue("@courseID", courseID);
                        command.Parameters.AddWithValue("@sectionID", sectionID);
                        command.Parameters.AddWithValue("@semesterID", semesterID);

                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        connection.Close();

                        if (rowsAffected > 0)

                        {
                            Response.Write("<script>alert('Course has been registered successfully.')</script>");

                        }


                    }
                }

            }

        }

    }


}