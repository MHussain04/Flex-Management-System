﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class OfferedCourses : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {
        if (!IsPostBack)

        {

            List<int> semesters = new List<int>();


            semesters.Insert(0, 0);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                conn.Open();

                SqlCommand cmd = new SqlCommand("SELECT Semester_ID from Semester", conn);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())

                {
                    semesters.Add(reader.GetInt32(0));
                }
            }

            DropDownList1.DataSource = semesters;
            DropDownList1.DataBind();


        }

    }

        protected void Button1_Click(object sender, EventArgs e)

    {
        int semesterID = Convert.ToInt32(Session["semesterID"]);

        if(semesterID == 0)

        {

            Response.Write("<script>alert('Please select valid semester.')</script>");
        }

        else


        Response.Redirect("OfferedCourses1.aspx?Semester_ID=" + semesterID);

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)

    {
        int semester_ID = Convert.ToInt32(DropDownList1.SelectedValue);

        Session["semesterID"] = semester_ID;

    }
}