﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Sign_Up : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)


    {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True");
            conn.Open();
            Label1.Text = "Connection Open";
            SqlCommand cm;

            string name = TextBox1.Text + " " + TextBox2.Text;
            string email = TextBox3.Text;
            string mobile = TextBox4.Text;
            string cnic = TextBox7.Text;
            string address = TextBox5.Text;
            DateTime dob = DateTime.ParseExact(TextBox6.Text, "yyyy-mm-dd", CultureInfo.InvariantCulture);
            string bloodGroup = TextBox11.Text;
            string gender = DropDownList1.SelectedValue;
            string username = TextBox8.Text;
            string password = TextBox9.Text;
            string re_enter_password = TextBox10.Text;
            string campus = TextBox12.Text;
            string role = "Academic Officer";

            if (password == re_enter_password)

            {
                string query = "INSERT INTO _User (Name, Email, Mobile_No, CNIC, Address, Campus, DOB, Blood_Group, Gender, Username, Password, Role) " +
                               "VALUES (@Name, @Email, @Mobile, @CNIC, @Address, @Campus, @DOB, @BloodGroup, @Gender, @Username, @Password, @Role)";
                cm = new SqlCommand(query, conn);
                cm.Parameters.AddWithValue("@Name", name);
                cm.Parameters.AddWithValue("@Email", email);
                cm.Parameters.AddWithValue("@Mobile", mobile);
                cm.Parameters.AddWithValue("@CNIC", cnic);
                cm.Parameters.AddWithValue("@Address", address);
                cm.Parameters.AddWithValue("@Campus", campus);
                cm.Parameters.AddWithValue("@DOB", dob);
                cm.Parameters.AddWithValue("@BloodGroup", bloodGroup);
                cm.Parameters.AddWithValue("@Gender", gender);
                cm.Parameters.AddWithValue("@Username", username);
                cm.Parameters.AddWithValue("@Password", password);
                cm.Parameters.AddWithValue("@Role", role);
                cm.ExecuteNonQuery();
                cm.Dispose();
                conn.Close();

            Response.Write("<script>alert('You have signed up successfully.')</script>");
          //  Response.Redirect("Login_Form.aspx");

            }

            else
        {

            Response.Write("<script>alert('Passwords Don't Match.')</script>");

        }
    }

 }

      