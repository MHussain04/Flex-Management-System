﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Evaluation1 : System.Web.UI.Page

{
    protected void Page_Load(object sender, EventArgs e)

    {

        int teacherId = Convert.ToInt32(Session["teacher_id"]);

        string courseName = Request.QueryString["Course_Name"];

        string connectionString = "Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True";

        using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

        {
            conn.Open();

            string query = "Select Courses.Course_ID, Courses.Course_Name, S_Details.Roll_Number, _User.Name, Student_Marks.Evaluation_Name, Student_Marks.Evaluation_Number,Student_Marks.Obtained_Marks, Student_Marks.Total_Marks, Student_Marks.my_grand_total from Student_Marks " +

                           "inner join S_Details on S_Details.Student_ID = Student_Marks.Student_ID " +

                           "inner join _User on _User.User_ID = S_Details.Student_ID " +

                           "inner join Courses on Courses.Course_ID = Student_Marks.Course_ID " +

                           "where Courses.Course_Name = @CourseName order by S_Details.Roll_Number ASC ";

            SqlCommand cmd = new SqlCommand(query, conn);

            cmd.Parameters.AddWithValue("@CourseName", courseName);

            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)

            {
                GridView1.DataSource = reader;
                GridView1.DataBind();
            }



            reader.Close();

        }

    }




        protected void MarksGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}