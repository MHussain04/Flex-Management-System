﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class OfferedCourses1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {
        int semesterID = Convert.ToInt32(Request.QueryString["Semester_ID"]);

        string connectionString = "Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True";

        using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

        {
            conn.Open();

            string query = "select Semester.Semester_Name, Courses.Course_ID,Courses.Course_Name, Courses.Credits from Courses " +

                "inner join Semester on Courses.Semester_ID = Semester.Semester_ID where Semester.Semester_ID = @semesterId";


            SqlCommand cmd = new SqlCommand(query, conn);


            cmd.Parameters.AddWithValue("@semesterId", semesterID);

            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)

            {
                GridView1.DataSource = reader;
                GridView1.DataBind();
            }

            else

            {
                GridView1.Visible = false;

                Response.Write("<script>alert('Semester has no offered courses yet.')</script>");

                return;
            }

            reader.Close();

        }


    }

    protected void MarksGridView_SelectedIndexChanged(object sender, EventArgs e)

    {

    }
}