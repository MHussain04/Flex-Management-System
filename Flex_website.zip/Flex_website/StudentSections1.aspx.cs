﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class StudentSections1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {
        if (!IsPostBack)

        {

            int sectionID = Convert.ToInt32(Request.QueryString["Section_ID"]);

            string connectionString = "Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True";

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                conn.Open();

                string query = "SELECT Section.Section_Name, S_Details.Roll_Number, _User.Name FROM _User " +

                  "INNER JOIN S_Details ON S_Details.Student_ID = _User.User_ID " +

                  "INNER JOIN Section ON Section.Section_ID = S_Details.Section_ID " +

                  "WHERE Section.Section_ID = @sectionID ORDER BY S_Details.Roll_Number ASC";




                SqlCommand cmd = new SqlCommand(query, conn);


                cmd.Parameters.AddWithValue("@sectionID", sectionID);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)

                {
                    GridView1.DataSource = reader;
                    GridView1.DataBind();
                }

                else

                {

                    GridView1.Visible = false;

                    Response.Write("<script>alert('No Students are currently in this section.')</script>");
                }

                reader.Close();
            }

        }

    }

    protected void MarksGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}