﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TeacherHomePage : System.Web.UI.Page

{
    protected void Page_Load(object sender, EventArgs e)
    {
        string name = (string)Session["Name"];
        string email = (string)Session["Email"];
        string mobileNo = (string)Session["Mobile_No"];
        string cnic = (string)Session["CNIC"];
        string address = (string)Session["Address"];
        DateTime dob = (DateTime)Session["DOB"];
        string dateOnly = dob.ToString("dd/MM/yyyy");
        string bloodGroup = (string)Session["Blood_Group"];
        string gender = (string)Session["Gender"];
        string campus = (string)Session["Campus"];

        Label10.Text = "Name: " + name;
        Label11.Text = "DOB: " + dateOnly;
        Label12.Text = "Blood Group: " + bloodGroup;
        Label13.Text = "Gender: " + gender;
        Label14.Text = "CNIC: " + cnic;
        Label15.Text = "Email: " + email;
        Label16.Text = "Mobile Number: " + mobileNo;
        Label19.Text = "Campus: " + campus;
        Label18.Text = "Address: " + address;
    }

    protected void LinkButton8_Click(object sender, EventArgs e)
    {
        Response.Redirect("Manage_Attendance1.aspx");
    }

    protected void LinkButton9_Click(object sender, EventArgs e)
    {
        Response.Redirect("MarksDistribution.aspx");
    }

    protected void LinkButton10_Click(object sender, EventArgs e)
    {
        Response.Redirect("ManageMarks.aspx");
    }

    protected void LinkButton11_Click(object sender, EventArgs e)

    {
        Response.Redirect("AllocatedCourses.aspx");
    }

    protected void LinkButton12_Click(object sender, EventArgs e)
    {
        Response.Redirect("Evaluation.aspx");
    }

    protected void LinkButton13_Click(object sender, EventArgs e)

    {
        Response.Redirect("GradeReport.aspx");

    }

    protected void LinkButton14_Click(object sender, EventArgs e)

    {
        Response.Redirect("GradeCount.aspx");
    }

    protected void LinkButton16_Click(object sender, EventArgs e)
    {
        Response.Redirect("AttendanceReport.aspx");
    }

    protected void LinkButton17_Click(object sender, EventArgs e)

    {
        Response.Redirect("TeacherFeedback.aspx");
    }
}