﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MarksEvaluation : System.Web.UI.Page

{
    protected void Page_Load(object sender, EventArgs e)

    {
        if (!IsPostBack)

        {
            // Retrieve the teacher ID from session variable
            int teacherId = Convert.ToInt32(Session["teacher_id"]);

            // Retrieve the courses for which the teacher is assigned
            List<string> courses = new List<string>();
            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT c.Course_Name FROM Teacher_Courses tc INNER JOIN Courses c ON tc.Course_ID = c.Course_ID WHERE tc.Teacher_ID = @TeacherID group by c.Course_Name", conn);
                cmd.Parameters.AddWithValue("@TeacherId", teacherId);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())

                {
                    courses.Add(reader.GetString(0));
                }
            }

            // Bind the courses to the drop-down list
            DropDownList1.DataSource = courses;
            DropDownList1.DataBind();
        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)

    {

        using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

        {
            conn.Open();

            int teacherId = Convert.ToInt32(Session["teacher_id"]);

            string courseName = DropDownList1.SelectedValue;

            int assignmentWeightage = Convert.ToInt32(TextBox1.Text);
            
            Session["assignmentWeightage"] = assignmentWeightage;

            int quizWeightage = Convert.ToInt32(TextBox2.Text);

            Session["QuizWeightage"] = quizWeightage;

            int mid1Weightage = Convert.ToInt32(TextBox3.Text);

            Session["Mid1Weightage"] = mid1Weightage;


            int mid2Weightage = Convert.ToInt32(TextBox4.Text);

            Session["Mid2Weightage"] = mid2Weightage;

            int Project_Weightage = Convert.ToInt32(TextBox5.Text);

            Session["ProjectWeightage"] = Project_Weightage;

            int finalWeightage = Convert.ToInt32(TextBox6.Text);

            Session["FinalWeightage"] = finalWeightage;



            int totalWeightage = assignmentWeightage + quizWeightage + mid1Weightage + mid2Weightage + Project_Weightage + finalWeightage;

            if (totalWeightage != 100)

            {
                Response.Write("<script>alert('Total weightage should be 100')</script>");
                
            }

            else

            {

                SqlCommand existsCmd = new SqlCommand("SELECT COUNT(*) FROM M_Distribution WHERE Evaluation_Name = 'Marks' AND Teacher_ID = @TeacherId AND Course_ID = (SELECT Course_ID FROM Courses WHERE Course_Name = @CourseName)", conn);
                existsCmd.Parameters.AddWithValue("@TeacherId", teacherId);
                existsCmd.Parameters.AddWithValue("@CourseName", courseName);
                int count = (int)existsCmd.ExecuteScalar();

                if (count > 0)

                {
                    // A record already exists, display a message and don't insert the weightages
                    Response.Write("<script>alert('Weightages for this course have already been added.')</script>");
                }

                else

                {


                    SqlCommand cmd = new SqlCommand("INSERT INTO M_Distribution (Evaluation_Name, Teacher_ID, Course_ID, Assignment_Weightage, Quiz_Weightage, Mid1_Weightage, Mid2_Weightage, Project_Weightage , Final_Weightage, Weightage) VALUES ('Marks', @TeacherId, (SELECT Course_ID FROM Courses WHERE Course_Name = @CourseName), @AssignmentWeightage, @QuizWeightage, @Mid1Weightage, @Mid2Weightage, @ProjectWeightage, @FinalWeightage, @TotalWeightage)", conn);

                    cmd.Parameters.AddWithValue("@CourseName", courseName);
                    cmd.Parameters.AddWithValue("@TeacherId", teacherId);
                    cmd.Parameters.AddWithValue("@AssignmentWeightage", assignmentWeightage);
                    cmd.Parameters.AddWithValue("@QuizWeightage", quizWeightage);
                    cmd.Parameters.AddWithValue("@Mid1Weightage", mid1Weightage);
                    cmd.Parameters.AddWithValue("@Mid2Weightage", mid2Weightage);
                    cmd.Parameters.AddWithValue("@ProjectWeightage", mid2Weightage);
                    cmd.Parameters.AddWithValue("@FinalWeightage", finalWeightage);
                    cmd.Parameters.AddWithValue("@TotalWeightage", totalWeightage);
                    cmd.ExecuteNonQuery();

                    // Display a success message if the weightage is valid and the insertion was successful
                    Response.Write("<script>alert('Weightages added successfully.')</script>");

                }
            }

        }

    }
        protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox5_TextChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox6_TextChanged(object sender, EventArgs e)
    {

    }
}