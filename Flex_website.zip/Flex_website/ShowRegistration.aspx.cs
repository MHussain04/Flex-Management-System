﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static System.Collections.Specialized.BitVector32;

public partial class ShowRegistrationaspx : System.Web.UI.Page

{
    protected void Page_Load(object sender, EventArgs e)

    {
        if (!IsPostBack)

        {


            int studentID = Convert.ToInt32(Session["student_id"]);

            string connectionString = "Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True";

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                conn.Open();

                string query = "Select Student_Courses.Course_ID,Courses.Course_Name,Courses.Course_Type,Semester.Semester_Name from Student_Courses " +
                    "inner join Courses on Courses.Course_ID = Student_Courses.Course_ID " +
                    "inner join Semester on semester.Semester_ID = Student_Courses.Semester_ID " +
                    "where Student_Courses.Student_ID = @StudentId order by Student_Courses.Course_ID ";


                SqlCommand cmd = new SqlCommand(query, conn);

             
                cmd.Parameters.AddWithValue("@StudentId", studentID);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)

                {
                    GridView1.DataSource = reader;
                    GridView1.DataBind();
                }

                else

                {
                    // If no marks are found, display a message to the teacher
                    GridView1.Visible = false;

                    Response.Write("<script>alert('You have not registered any courses yet.')</script>");

                }

                reader.Close();
            }
        }
    }



    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)

    {
        Response.Redirect("CourseRegistration.aspx");
    }
}