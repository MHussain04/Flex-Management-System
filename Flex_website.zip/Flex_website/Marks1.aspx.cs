﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Marks1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            string coursename = Request.QueryString["CourseName"];
            string courseID = Request.QueryString["CourseID"];
            int sectionID = Convert.ToInt32(Request.QueryString["SectionID"]);
            int semesterID = Convert.ToInt32(Request.QueryString["SemesterID"]);

            int studentID = Convert.ToInt32(Session["student_id"]);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                conn.Open();

                string query = "SELECT Evaluation_Number, Evaluation_Name, Obtained_Marks, Total_Marks, my_grand_total " +
                    "FROM Student_Marks " +
                    "WHERE Course_ID = @CourseId AND Section_ID = @SectionId " +
                    "AND Semester_ID = @SemesterId AND Student_ID = @StudentId";

                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@StudentID", studentID);

                cmd.Parameters.AddWithValue("@CourseID", courseID);

                cmd.Parameters.AddWithValue("@SectionID", sectionID);

                cmd.Parameters.AddWithValue("@SemesterID", semesterID);

                SqlDataReader reader = cmd.ExecuteReader();


                if (reader.HasRows)

                {
                    GridView1.DataSource = reader;

                    GridView1.DataBind();

                }

                else

                {
                    Response.Write("<script>alert('Marks have not been entered for this course yet.')</script>");

                }

                reader.Close();
            }


        }


    }



    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}