﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ManageMarks1 : System.Web.UI.Page

{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)

        {
            int teacherId = Convert.ToInt32(Session["teacher_id"]);
            string courseId = Request.QueryString["CourseID"];
            int sectionId = Convert.ToInt32(Request.QueryString["SectionID"]);
            int semesterId = Convert.ToInt32(Request.QueryString["SemesterID"]);
            int studentId = Convert.ToInt32(Request.QueryString["StudentID"]);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                conn.Open();

                string query = "SELECT Evaluation_Number, Evaluation_Name, Obtained_Marks, Total_Marks, my_grand_total " +
                    "FROM Student_Marks " +
                    "WHERE Teacher_ID = @TeacherId AND Course_ID = @CourseId AND Section_ID = @SectionId " +
                    "AND Semester_ID = @SemesterId AND Student_ID = @StudentId";

                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@TeacherId", teacherId);
                cmd.Parameters.AddWithValue("@CourseId", courseId);
                cmd.Parameters.AddWithValue("@SectionId", sectionId);
                cmd.Parameters.AddWithValue("@SemesterId", semesterId);
                cmd.Parameters.AddWithValue("@StudentId", studentId);

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)

                {
                    MarksGridView.DataSource = reader;
                    MarksGridView.DataBind();
                }

                else

                {
                    // If no marks are found, display a message to the teacher
                    MarksGridView.Visible = false;

                    Response.Write("<script>alert('No marks have been added for the current student.')</script>");

                }

                reader.Close();
            }
        }
    }

    protected void Button1_Click(object sender, EventArgs e)

    {
        string courseId = Request.QueryString["CourseID"];
        int sectionId = Convert.ToInt32(Request.QueryString["SectionID"]);
        int semesterId = Convert.ToInt32(Request.QueryString["SemesterID"]);
        int studentId = Convert.ToInt32(Request.QueryString["StudentID"]);

        Response.Redirect("AddMarks.aspx?CourseID=" + courseId + "&SectionID=" + sectionId + "&SemesterID=" + semesterId + "&StudentID=" + studentId);
    }

    protected void MarksGridView_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}