﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Attendence1 : System.Web.UI.Page

{
    protected void Page_Load(object sender, EventArgs e)

    {
        if (!IsPostBack)
        {
            string courseID = Request.QueryString["CourseID"];

            int sectionID = Convert.ToInt32(Request.QueryString["SectionID"]);

            int semesterID = Convert.ToInt32(Request.QueryString["SemesterID"]);

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                conn.Open();

                string query = "SELECT Lecture_No, Date, Duration, Presence FROM Attendance WHERE Course_ID = @CourseID AND Section_ID = @SectionID AND Semester_ID = @SemesterID AND Student_ID = @StudentID";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CourseID", courseID);
                cmd.Parameters.AddWithValue("@SectionID", sectionID);
                cmd.Parameters.AddWithValue("@SemesterID", semesterID);
                cmd.Parameters.AddWithValue("@StudentID", Convert.ToInt32(Session["student_id"]));

                SqlDataReader reader = cmd.ExecuteReader();

                int presentCount = 0;
                int totalCount = 0;

                while (reader.Read())

                {
                    totalCount++;

                    if (reader["Presence"].ToString() == "P" || reader["Presence"].ToString() == "L")

                    {
                        presentCount++;
                    }
                }

                if (totalCount > 0)

                {
                    double percentage = (double)presentCount / totalCount * 100;

                    Label1.Text = string.Format("Attendance Percentage: {0:F2}%", percentage);
                    Label1.ForeColor = System.Drawing.Color.White;
                }

                else
                {
                    Label1.Text = "No attendance records were found for this course.";
                    Label1.ForeColor = System.Drawing.Color.White;
                }

                reader.Close();
                cmd.Dispose();

                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                adapter.SelectCommand.Parameters.AddWithValue("@CourseID", courseID);

                adapter.SelectCommand.Parameters.AddWithValue("@SectionID", sectionID);

                adapter.SelectCommand.Parameters.AddWithValue("@SemesterID", semesterID);

                adapter.SelectCommand.Parameters.AddWithValue("@StudentID", Convert.ToInt32(Session["student_id"]));

                DataTable dt = new DataTable();
                adapter.Fill(dt);

                GridView1.DataSource = dt;
                GridView1.DataBind();

                conn.Close();
            }
        }
    }


    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)

    {

    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)

    {


    }


}