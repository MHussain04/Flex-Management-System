﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Evaluation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {

        if (!IsPostBack)

        {
            int teacherId = Convert.ToInt32(Session["teacher_id"]);

            List<string> courses = new List<string>();

            courses.Insert(0, "-");

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT c.Course_Name FROM Teacher_Courses tc INNER JOIN Courses c ON tc.Course_ID = c.Course_ID WHERE tc.Teacher_ID = @TeacherID group by c.Course_Name", conn);
                cmd.Parameters.AddWithValue("@TeacherId", teacherId);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())

                {
                    courses.Add(reader.GetString(0));
                }
            }


            DropDownList1.DataSource = courses;
            DropDownList1.DataBind();

        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)

    {

        int teacherId = Convert.ToInt32(Session["teacher_id"]);

        string coursename = DropDownList1.SelectedValue;


        Session["Course_Name"] = coursename;


    }

    protected void Button1_Click(object sender, EventArgs e)

    {

        int teacherId = Convert.ToInt32(Session["teacher_id"]);

        if (Session["Course_Name"] != null)

        {
            string courseName = Session["Course_Name"].ToString();

            Response.Redirect("Evaluation1.aspx?Course_Name=" + courseName);
        }

        else

        {

            Response.Write("<script>alert('Please select valid course.')</script>");

        }

    }
}