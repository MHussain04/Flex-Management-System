﻿using System;
using System.Activities.Expressions;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static System.Collections.Specialized.BitVector32;

public partial class CourseAllocation1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)

    {

        if (!IsPostBack)

        {


            string Teacher_ID = Request.QueryString["Teacher_ID"];

            string connectionString = "Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True";

            string query = "SELECT Course_ID, Course_Name, Credits, Course_Type, Semester_Name " +
                   "FROM Courses " +
                   "INNER JOIN Semester ON Courses.Semester_ID = Semester.Semester_ID " +
                 //  "INNER JOIN Section ON Courses.Semester_ID = Section.Semester_ID " + 
                   "GROUP BY Courses.Course_ID, Courses.Course_Name, Courses.Credits, Courses.Course_Type, Semester.Semester_Name " +
                   "ORDER BY Courses.Course_Name";

            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                // Bind the data to the GridView control
                GridView1.DataSource = reader;
                GridView1.DataBind();

                reader.Close();
            }

        }
    }

    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)

    {

        bool flag = true;


        if (e.CommandName == "Allocate")

        {

            int rowIndex = Convert.ToInt32(e.CommandArgument);

            GridViewRow row = GridView1.Rows[rowIndex];

            // Retrieve the values from the GridView row
            string courseID = row.Cells[0].Text;

            string teacherId = Request.QueryString["Teacher_ID"];

            DropDownList ddlSection = (DropDownList)row.FindControl("DropDownList1");
            string sectionId = ddlSection.SelectedValue;


            int semesterId = 0;

            string connectionString = "Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True";

            string query = "SELECT Semester_ID FROM Courses WHERE Course_ID = @Course_ID";

            using (SqlConnection conn = new SqlConnection(connectionString))

            using (SqlCommand cmd = new SqlCommand(query, conn))

            {


                conn.Open();

                cmd.Parameters.AddWithValue("@Course_ID", courseID);

                semesterId = (int)cmd.ExecuteScalar();

                query = "SELECT COUNT(*) FROM Teacher_Courses WHERE Section_ID = @Section_ID AND Course_ID = @Course_ID";

                using (SqlCommand cmd2 = new SqlCommand(query, conn))

                {
                    cmd2.Parameters.AddWithValue("@Teacher_ID", teacherId);

                    cmd2.Parameters.AddWithValue("@Section_ID", sectionId);

                    cmd2.Parameters.AddWithValue("@Course_ID", courseID);

                    int count = (int)cmd2.ExecuteScalar();

                    if (count > 0)

                    {

                        Response.Write("<script>alert('Error: Course already allocated to the teacher for the same section.')</script>");
                        flag = false;
                    }

                }

                query = "SELECT COUNT(*) FROM Teacher_Courses WHERE Teacher_ID = @Teacher_ID AND Semester_ID = @Semester_ID";

                using (SqlCommand cmd3 = new SqlCommand(query, conn))

                {
                    cmd3.Parameters.AddWithValue("@Teacher_ID", teacherId);

                    cmd3.Parameters.AddWithValue("@Semester_ID", semesterId);

                    int count = (int)cmd3.ExecuteScalar();

                    if (count >= 3)

                    {

                        Response.Write("<script>alert('Error: Teacher already has 3 courses allocated.')</script>");
                        flag = false;

                    }


                }


                if (flag == true)

                {


                    query = "INSERT INTO Teacher_Courses (Teacher_ID, Course_ID, Section_ID, Semester_ID) VALUES (@Teacher_ID, @Course_ID, @Section_ID, @Semester_ID)";

                    using (SqlCommand cmd4 = new SqlCommand(query, conn))

                    {
                        cmd4.Parameters.AddWithValue("@Teacher_ID", teacherId);

                        cmd4.Parameters.AddWithValue("@Course_ID", courseID);

                        cmd4.Parameters.AddWithValue("@Section_ID", sectionId);

                        cmd4.Parameters.AddWithValue("@Semester_ID", semesterId);

                        int rowsAffected = cmd4.ExecuteNonQuery();

                        if (rowsAffected > 0)

                        {

                            Response.Write("<script>alert('Course successfully allocated.')</script>");

                        }


                    }

                }

            }

        }


    }


    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)

    {

    }
}
