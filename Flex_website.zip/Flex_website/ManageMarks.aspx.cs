﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static System.Collections.Specialized.BitVector32;

public partial class ManageMarks : System.Web.UI.Page

{
    protected void Page_Load(object sender, EventArgs e)

    {
        if (!IsPostBack)

        {
            int teacherId = Convert.ToInt32(Session["teacher_id"]);

            List<string> courses = new List<string>();

            courses.Insert(0, "-");

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT c.Course_Name FROM Teacher_Courses tc INNER JOIN Courses c ON tc.Course_ID = c.Course_ID WHERE tc.Teacher_ID = @TeacherID group by c.Course_Name", conn);
                cmd.Parameters.AddWithValue("@TeacherId", teacherId);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())

                {
                    courses.Add(reader.GetString(0));
                }
            }


            DropDownList1.DataSource = courses;
            DropDownList1.DataBind();

        }
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)

    {

        int teacherId = Convert.ToInt32(Session["teacher_id"]);

        string courseId = DropDownList1.SelectedValue;


        List<string> sections = new List<string>();

        sections.Insert(0, "-");

        using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT Section_Name from Teacher_Courses inner join Section on section.Section_ID = Teacher_Courses.Section_ID inner join Courses on Courses.Course_ID = Teacher_Courses.Course_ID where Teacher_ID = @TeacherId AND Courses.Course_Name = @CourseID", conn);

            cmd.Parameters.AddWithValue("@TeacherId", teacherId);

            cmd.Parameters.AddWithValue("@CourseID", courseId);

            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())

            {
                sections.Add(reader.GetString(0));

            }

            DropDownList2.DataSource = sections;
            DropDownList2.DataBind();
        }
    }

    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)

    {

        int teacherId = Convert.ToInt32(Session["teacher_id"]);

        string Coursename = DropDownList1.SelectedValue;

        string sectionname = DropDownList2.SelectedValue;

        List<int> students = new List<int>();

        using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

        {
            conn.Open();

            SqlCommand cmd = new SqlCommand("SELECT S_Details.Student_ID FROM S_Details INNER JOIN Student_Courses ON Student_Courses.Student_ID = S_Details.Student_ID inner join Courses on Courses.Course_ID = Student_Courses.Course_ID inner join Section on Section.Section_ID = S_Details.Section_ID WHERE Courses.Course_Name = @Coursename AND Section.Section_Name = @Sectionname", conn);

            cmd.Parameters.AddWithValue("@Coursename", Coursename);

            cmd.Parameters.AddWithValue("@Sectionname", sectionname);

            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())

            {
                students.Add(reader.GetInt32(0));
            }

            DropDownList3.DataSource = students;
            DropDownList3.DataBind();
        }
    }

    
    protected void Button1_Click(object sender, EventArgs e)

    {

        int teacherId = Convert.ToInt32(Session["teacher_id"]);

        string Coursename = DropDownList1.SelectedValue;

        string sectionname = DropDownList2.SelectedValue;

        int studentID;

        if (int.TryParse(DropDownList3.SelectedValue, out studentID))

        {

            using (SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True"))

            {
                conn.Open();




                string query = "SELECT Courses.Course_Name,Teacher_Courses.Course_ID, Teacher_Courses.Section_ID,Teacher_Courses.Semester_ID, Section.Section_Name from Teacher_Courses " +
                    "Inner join Courses on Courses.Course_ID = Teacher_Courses.Course_ID " +
                    "Inner join Section on Section.Section_ID = Teacher_Courses.Section_ID " +
                    "WHERE Teacher_ID = @teacherID AND Course_Name = @Coursename AND Section.Section_Name = @sectionname";


                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@teacherID", teacherId);

                cmd.Parameters.AddWithValue("@sectionname", sectionname);

                cmd.Parameters.AddWithValue("@Coursename", Coursename);


                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())

                {

                    string courseID = reader["Course_ID"].ToString();
                    string sectionID = reader["Section_ID"].ToString();
                    string semesterID = reader["Semester_ID"].ToString();


                    Response.Redirect("ManageMarks1.aspx?&SelectedValue=" + sectionname + "&CourseID=" + courseID + "&SectionID=" + sectionID + "&SemesterID=" + semesterID + "&StudentID=" + studentID);
                }

                reader.Close();
            }

        }

        else

            Response.Write("<script>alert('Please select a student.')</script>");

    }

    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)

    {

    }
}