﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TeacherRegistration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)

    {

        string name = TextBox1.Text;

        string campus = TextBox11.Text;

        string email = TextBox2.Text;

        string mobile  = TextBox3.Text;

        string cnic = TextBox4.Text;

        string address = TextBox5.Text;

        DateTime dob = DateTime.Parse(TextBox6.Text).Date;

        string blood = TextBox7.Text;

        string gender = DropDownList1.SelectedValue;

        string username = TextBox8.Text;

        string password = TextBox9.Text;

        string role = "Faculty";

        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-04P2OKF\\SQLEXPRESS;Initial Catalog=Flex2;Integrated Security=True");

        conn.Open();

        SqlCommand cmdCheck = new SqlCommand("SELECT COUNT(*) FROM _User WHERE Username = @username", conn);

        cmdCheck.Parameters.AddWithValue("@username",username);

        int count = Convert.ToInt32(cmdCheck.ExecuteScalar());

        if (count > 0)
        {
            Response.Write("<script>alert('A Teacher with the same username already exists.')</script>");
            return;
        }

        SqlCommand cmdUser = new SqlCommand("INSERT INTO _User (Name, Email, Mobile_No, CNIC, Address, Campus, DOB, Blood_Group, Gender, Username, Password, Role) VALUES (@Name, @Email, @Mobile, @CNIC, @Address, @Campus, @DOB, @BloodGroup, @Gender, @Username, @Password, @Role); SELECT SCOPE_IDENTITY();", conn);
        cmdUser.Parameters.AddWithValue("@Name", name);
        cmdUser.Parameters.AddWithValue("@Email", email);
        cmdUser.Parameters.AddWithValue("@Mobile", mobile);
        cmdUser.Parameters.AddWithValue("@CNIC", cnic);
        cmdUser.Parameters.AddWithValue("@Address", address);
        cmdUser.Parameters.AddWithValue("@Campus", campus);
        cmdUser.Parameters.AddWithValue("@DOB", dob);
        cmdUser.Parameters.AddWithValue("@BloodGroup", blood);
        cmdUser.Parameters.AddWithValue("@Gender", gender);
        cmdUser.Parameters.AddWithValue("@Username", username);
        cmdUser.Parameters.AddWithValue("@Password", password);
        cmdUser.Parameters.AddWithValue("@Role", role);


        Response.Write("<script>alert('Teacher has been registered successfully.')</script>");

        cmdUser.ExecuteNonQuery();
    }
}